package library;

import java.io.*;
import java.util.Scanner;

		public class LibraryApp {

		    private static final String FILE_NAME = "books.txt";

		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);
		        while (true) {
		            System.out.println("\n1) Kitap Ekle");
		            System.out.println("2) Kitapları Listele");
		            System.out.println("3) Kitap Ara");
		            System.out.println("4) Çıkış");
		            System.out.print("Seçim: ");
		            int secim = sc.nextInt(); sc.nextLine();

		            if (secim == 1) addBook(sc);
		            else if (secim == 2) listBooks();
		            else if (secim == 3) searchBook(sc);
		            else if (secim == 4) break;
		            else System.out.println("Geçersiz seçim!");
		        }
		        sc.close();
		    }

		    private static void addBook(Scanner sc) {
		        System.out.print("Kitap ID: ");
		        String id = sc.nextLine();
		        System.out.print("Kitap Adı: ");
		        String title = sc.nextLine();
		        System.out.print("Yazar: ");
		        String author = sc.nextLine();

		        Book b = new Book(title, author, id);
		        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
		            bw.write(b.toString());
		            bw.newLine();
		        } catch (IOException e) {
		            System.out.println("Dosyaya yazarken hata!");
		        }
		        System.out.println("Kitap kaydedildi.");
		    }

		    private static void listBooks() {
		        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
		            String line;
		            System.out.println("\n--- Kayıtlı Kitaplar ---");
		            while ((line = br.readLine()) != null) {
		                String[] arr = line.split(",");
		                System.out.println("ID: " + arr[0] + ", Kitap: " + arr[1] + ", Yazar: " + arr[2]);
		            }
		        } catch (IOException e) {
		            System.out.println("Henüz kayıt yok.");
		        }
		    }

		    private static void searchBook(Scanner sc) {
		        System.out.print("Aranacak kelime (ad/ID/yazar): ");
		        String text = sc.nextLine();
		        boolean found = false;

		        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
		            String line;
		            while ((line = br.readLine()) != null) {
		                if (line.contains(text)) {
		                    String[] arr = line.split(",");
		                    System.out.println("Bulundu → ID: " + arr[0] + ", Kitap: " + arr[1] + ", Yazar: " + arr[2]);
		                    found = true;
		                }
		            }
		        } catch (IOException e) {}
		        if (!found) System.out.println("Sonuç yok.");
		    }
		}
